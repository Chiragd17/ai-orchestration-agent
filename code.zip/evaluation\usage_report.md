# Hackathon Evaluation: Token Usage & Cost Report

**Total Requests Evaluated:** 250

## Overall Totals
- **Total Model Calls:** 250
- **Total Input Tokens:** 61,909
- **Total Output Tokens:** 14,256
- **Total Tokens:** 76,165
- **Average Tokens / Request:** 304.7
- **Estimated Total Cost:** $0.00381
- **Estimated Cost / Request:** $0.00002

## Per-Model Breakdown
### Model: `qwen/qwen3.8-27b`
- **Calls:** 250
- **Input Tokens:** 61,909
- **Output Tokens:** 14,256
- **Estimated Cost:** $0.00381
